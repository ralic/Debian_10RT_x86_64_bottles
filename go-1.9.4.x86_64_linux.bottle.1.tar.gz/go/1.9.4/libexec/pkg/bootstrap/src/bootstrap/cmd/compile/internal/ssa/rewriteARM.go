package ssa

func rewriteValueARM(v *Value) bool { panic("unused during bootstrap") }
func rewriteBlockARM(b *Block) bool { panic("unused during bootstrap") }

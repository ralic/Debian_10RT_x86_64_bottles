package ssa

func rewriteValue386(v *Value) bool { panic("unused during bootstrap") }
func rewriteBlock386(b *Block) bool { panic("unused during bootstrap") }

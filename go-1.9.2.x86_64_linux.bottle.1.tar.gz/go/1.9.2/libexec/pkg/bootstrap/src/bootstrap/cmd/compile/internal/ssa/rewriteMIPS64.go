package ssa

func rewriteValueMIPS64(v *Value) bool { panic("unused during bootstrap") }
func rewriteBlockMIPS64(b *Block) bool { panic("unused during bootstrap") }

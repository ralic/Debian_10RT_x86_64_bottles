/* Generated automatically. */
static const char configuration_arguments[] = "../configure --prefix=@@HOMEBREW_PREFIX@@/Cellar/gcc/7.3.0_1  --enable-languages=c,c++,objc,obj-c++,ada,fortran --program-suffix=-7 --with-gmp=@@HOMEBREW_PREFIX@@/opt/gmp --with-mpfr=@@HOMEBREW_PREFIX@@/opt/mpfr --with-mpc=@@HOMEBREW_PREFIX@@/opt/libmpc --with-isl=@@HOMEBREW_PREFIX@@/opt/isl  --enable-stage1-checking --enable-checking=release --enable-lto --with-build-config=bootstrap-debug --disable-werror --with-pkgversion='Homebrew gcc 7.3.0_1' --with-bugurl=https://github.com/Homebrew/homebrew/issues --with-boot-ldflags='-static-libstdc++ -static-libgcc ' --disable-nls --disable-multilib";
static const char thread_model[] = "posix";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "cpu", "generic" }, { "arch", "x86-64" } };
